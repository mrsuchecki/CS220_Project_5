import { sempty, snode } from "../include/stream.js";
export function addSeries(s, t) {
    return s.isEmpty() && t.isEmpty()
        ? sempty()
        : s.isEmpty()
            ? t
            : t.isEmpty()
                ? s
                : snode(s.head() + t.head(), () => addSeries(s.tail(), t.tail()));
}
export function prodSeries(s, t) {
    const h = s.head() * t.head();
    const tl = () => addSeries(t.tail().map(x => x * s.head()), prodSeries(s.tail(), t));
    return snode(h, tl);
}
export function derivSeries(s) {
    const h = s.head();
    const t = s.tail();
    if (t.isEmpty()) {
        return sempty();
    }
    const followingCoeff = t.head();
    const followingStream = derivSeries(t);
    return snode(h * 1, () => snode(followingCoeff * 2, () => followingStream));
}
export function coeff(s, n) {
    if (s.isEmpty()) {
        return [];
    }
    const result = [];
    for (let i = 0; i <= n && !s.isEmpty(); i++) {
        result.push(s.head());
        s = s.tail();
    }
    return result;
}
export function evalSeries(s, n) {
    const c = coeff(s, n);
    return (x) => {
        let total = 0;
        let expPower = 1;
        for (let i = 0; i <= n; i++) {
            total += c[i] * expPower;
            expPower *= x;
        }
        return total;
    };
}
export function applySeries(f, v) {
    return snode(v, () => applySeries(f, f(v)));
}
export function expSeries() {
    function term(n) {
        return 1 / factorial(n);
    }
    function factorial(n) {
        if (n === 0) {
            return 1;
        }
        else {
            return n * factorial(n - 1);
        }
    }
    return applySeries(term, 1);
}
export function recurSeries(coef, init) {
    const h = init[0];
    const t = () => recurSeries(coef, [...init.slice(1), coef.reduce((acc, cur, i) => acc + cur * init[i], 0)]);
    return snode(h, t);
}
//# sourceMappingURL=series.js.map